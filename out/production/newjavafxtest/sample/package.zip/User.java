package sample;
/*Liam Kelly 8909849*/
public abstract class User
{
    // instance variables - replace the example below with your own
    private String colour="red";
    protected double radius;

    /**
     * Constructor for objects of class circleBase
     */
    public User()
    {
        // initialise instance variables
        
    }

    
    
    
 
    
    //public abstract int getindexofuser();
    
    //public abstract boolean getchecklogin(int password);
    
    
    
    
     
    
}